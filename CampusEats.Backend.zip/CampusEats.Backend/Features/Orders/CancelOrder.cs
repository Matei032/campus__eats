﻿using CampusEats.Backend.Common;
using CampusEats.Backend.Common.DTOs;
using CampusEats.Backend.Persistence;
using FluentValidation;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace CampusEats.Backend.Features.Orders;

public static class CancelOrder
{
    // COMMAND
    public record Command : IRequest<Result<OrderDto>>
    {
        public Guid OrderId { get; init; }
        public Guid UserId { get; init; }  // For authorization (only order owner can cancel)
        public string? CancellationReason { get; init; }
    }
    
    // VALIDATOR
    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.OrderId)
                .NotEmpty().WithMessage("Order ID is required");

            RuleFor(x => x.UserId)
                .NotEmpty().WithMessage("User ID is required");

            RuleFor(x => x.CancellationReason)
                .MaximumLength(500).WithMessage("Cancellation reason cannot exceed 500 characters")
                .When(x => !string.IsNullOrEmpty(x.CancellationReason));
        }
    }
    
    // HANDLER
    internal sealed class Handler : IRequestHandler<Command, Result<OrderDto>>
    {
        private readonly AppDbContext _context;

        public Handler(AppDbContext context)
        {
            _context = context;
        }

        public async Task<Result<OrderDto>> Handle(Command request, CancellationToken cancellationToken)
        {
            // 1. Get order with related data
            var order = await _context.Orders
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.Product)
                .FirstOrDefaultAsync(o => o.Id == request.OrderId, cancellationToken);

            if (order is null)
            {
                return Result<OrderDto>.Failure($"Order with ID {request.OrderId} not found");
            }

            // 2. Authorization: Verify user owns this order
            if (order.UserId != request.UserId)
            {
                return Result<OrderDto>.Failure("You are not authorized to cancel this order");
            }

            // 3. Validate cancellation is allowed
            if (order.Status == "Completed")
            {
                return Result<OrderDto>.Failure("Cannot cancel completed order");
            }

            if (order.Status == "Cancelled")
            {
                return Result<OrderDto>.Failure("Order is already cancelled");
            }

            // 4. Optional: Time-based validation (only cancel within X minutes)
            var timeSinceCreation = DateTime.UtcNow - order.CreatedAt;
            if (order.Status == "Preparing" && timeSinceCreation.TotalMinutes > 5)
            {
                return Result<OrderDto>.Failure(
                    "Cannot cancel order that has been preparing for more than 5 minutes. Please contact staff.");
            }

            // 5. Cancel order
            order.Status = "Cancelled";
            order.PaymentStatus = "Refunded";  // Auto-mark for refund
            order.UpdatedAt = DateTime.UtcNow;
            
            // Optional: Store cancellation reason in Notes
            if (!string.IsNullOrEmpty(request.CancellationReason))
            {
                order.Notes = string.IsNullOrEmpty(order.Notes)
                    ? $"Cancelled: {request.CancellationReason}"
                    : $"{order.Notes}\nCancelled: {request.CancellationReason}";
            }

            // 6. TODO: Refund logic
            // - If paid with Card → initiate refund
            // - If paid with Loyalty → restore loyalty points
            // - Send notification to customer

            // 7. Save changes
            await _context.SaveChangesAsync(cancellationToken);

            // 8. Map to DTO
            var orderDto = new OrderDto
            {
                Id = order.Id,
                OrderNumber = order.OrderNumber,
                UserId = order.UserId,
                TotalAmount = order.TotalAmount,
                Status = order.Status,
                PaymentStatus = order.PaymentStatus,
                PaymentMethod = order.PaymentMethod,
                Notes = order.Notes,
                CreatedAt = order.CreatedAt,
                UpdatedAt = order.UpdatedAt,
                CompletedAt = order.CompletedAt,
                OrderItems = order.OrderItems.Select(oi => new OrderItemDto
                {
                    Id = oi.Id,
                    ProductId = oi.ProductId,
                    ProductName = oi.Product.Name,
                    Quantity = oi.Quantity,
                    UnitPrice = oi.UnitPrice,
                    Subtotal = oi.Subtotal,
                    SpecialInstructions = oi.SpecialInstructions
                }).ToList()
            };

            return Result<OrderDto>.Success(orderDto);
        }
    }
}